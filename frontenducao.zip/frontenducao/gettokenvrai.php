<?php
$ch = curl_init();

$token=$_REQUEST["token"];
$prenom=$_REQUEST["prenom"];
$nom=$_REQUEST["nom"];
$numcompte=$_REQUEST["numcompte"];
$codeclient=$_REQUEST["codeclient"];
$solde=$_REQUEST["solde"];

$headers1 = array();
$headers1[] = 'Content-Type: application/json';
$headers1[] = 'Authorization: Bearer '.$token;
$data=json_encode(["prenom"=>$prenom,"nom"=>$nom,"numcompte"=>$numcompte,"codeclient"=>$codeclient,"solde"=>$solde]);

$ch1 = curl_init();
curl_setopt($ch1, CURLOPT_URL, 'http://localhost:8000/api/creation');
curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch1, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch1, CURLOPT_POSTFIELDS,$data);
curl_setopt($ch1, CURLOPT_HTTPHEADER, $headers1);
$tab = curl_exec($ch1);
print_r($tab);
curl_close($ch1);

?>
