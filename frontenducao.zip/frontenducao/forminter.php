<?php
function tokenpournoir($email,$password)
{

$ch = curl_init();
$data=["email"=>$email,"password"=>$password];
$data1=json_encode($data);
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8000/authentication_token');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$data1);

$headers = array();
$headers[] = 'Content-Type: application/json';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);

$tok=json_decode($result);
$token=$tok->token;
return($token);
}

$email=$_REQUEST['email'];
$password=$_REQUEST['password'];
$token1=tokenpournoir($email,$password);
$chaine='<form action="intercreate.php" method="post"><div><label for="prenom">Prenom :</label><input type="text" id="prenom" name="prenom"></div><div>
        <label for="nom">Nom :</label>
        <input type="text" id="nom" name="nom">
    </div>
    <div>
        <label for="numcompte">NumCompte :</label>
        <input type="text" id="numcompte" name="numcompte">
    </div>
    <div>
        <label for="codeclient">CodeClient :</label>
        <input type="text" id="codeclient" name="codeclient">
    </div>
    <div>
        <label for="solde">Solde :</label>
        <input type="text" id="solde" name="solde">
    </div>
     <input type="hidden" name="token" value=';
 $chaine=$chaine.$token1.">";
 $chaine=$chaine.'<div><input type="submit" value="Valider"></div></form>';
echo $chaine;
?>
