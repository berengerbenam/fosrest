<?php
function tokenpournoir($email,$password)
{

$ch = curl_init();
$data=["email"=>$email,"password"=>$password];
$data1=json_encode($data);
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8000/authentication_token');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$data1);

$headers = array();
$headers[] = 'Content-Type: application/json';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);

$tok=json_decode($result);
$token=$tok->token;
return($token)
}
?>
