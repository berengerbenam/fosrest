<?php
$ch = curl_init();

$email=$_REQUEST["email"];
$password=$_REQUEST["password"];
$data=["email"=>$email,"password"=>$password];
$data1=json_encode($data);
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8000/authentication_token');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$data1);

$headers = array();
$headers[] = 'Content-Type: application/json';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);

$tok=json_decode($result);
$token=$tok->token;
$headers1 = array();
$headers1[] = 'Content-Type: application/json';
$headers1[] = 'Authorization: Bearer '.$token;

$ch1 = curl_init();
curl_setopt($ch1, CURLOPT_URL, 'http://localhost:8000/api/lecture');
curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch1, CURLOPT_CUSTOMREQUEST, "GET");
curl_setopt($ch1, CURLOPT_HTTPHEADER, $headers1);
$tab = curl_exec($ch1);
print_r($tab);
curl_close($ch1);

?>
