<?php
$token1=$_REQUEST["token"];
$prenom=$_REQUEST["prenom"];
$nom=$_REQUEST["nom"];
$numcompte=$_REQUEST["numcompte"];
$codeclient=$_REQUEST["codeclient"];
$solde=$_REQUEST["solde"];
$data = array("prenom"=>$prenom,"nom"=>$nom,"numcompte"=>$numcompte,"codeclient"=>$codeclient,"solde"=>$solde);
$data1= json_encode($data);
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'http://127.0.0.1:8000/api/creation');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data1);

$headers = array();
$headers[] = 'Authorization:  Bearer '.$token1;
$headers[] = 'Content-Type: application/json';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);
print_r($result);

?>
